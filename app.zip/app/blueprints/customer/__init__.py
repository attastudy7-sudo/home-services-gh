from flask import Blueprint

customer_bp = Blueprint('customer', __name__, template_folder='../../templates/customer')

from app.blueprints.customer import routes
